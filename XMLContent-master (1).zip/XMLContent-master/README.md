Module omekas
